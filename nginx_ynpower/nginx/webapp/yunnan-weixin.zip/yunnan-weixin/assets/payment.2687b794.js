import{r as e}from"./request.531acb17.js";const o=t=>e.get("/ynpower/paymentaccount/getPayAccountDetailInfo",{params:t}),a=t=>e.post("/ynpower/pay/pay",t);export{o as g,a as p};
